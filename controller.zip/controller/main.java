package controller;

import java.util.Scanner;

import model.Conta;
import model.Lancamento;
import model.Usuario;

public class main {

	/*static Lancamento lancamento = new Conta(0);
	
		static Scanner scan = new Scanner(System.in);
		public static void main(String[] args) {
			System.out.println("Forne�a seu nome de usu�rio para cadastro");
			usuario.setUsuario(scan.next());
			System.out.println("Agora sua senha");
			usuario.setSenha(scan.next());
			operar();
		}

		private static void operar() {
			System.out.println("Bem vindo! Deseja Realizar qual opera��o?\n1-Lan�amento\n2-Extrato\n0-Sair\n");
			int controlador = 0;
			controlador = scan.nextInt();
			switch (controlador) {
									case 1:
										lancamento();
*/
	
}
