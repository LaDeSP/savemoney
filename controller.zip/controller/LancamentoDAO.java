package controller;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import model.Lancamento;
import model.Receitas;
import model.Despesas;

public class LancamentoDAO{
	private static List<Lancamento> listaLancamentos = new ArrayList ();
	
	
	public static void criar(Date data, String descricao, float valor, char tipo){
		
		if(tipo == Lancamento.RECEITAS){
			Receitas novo = new receita(data, descricao, valor);
			listaLancamentos.add(novo);
		
	}
	/*	else if (tipo == Lancamento.Despesas){
			Despesas novo = new despesa (data, descricao, valor);
			listaLancamentos.add(novo);
		}*/

}
