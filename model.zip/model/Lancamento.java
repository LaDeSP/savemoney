package model;

import java.util.Scaner;
import java.util.Date;

public class Lancamento {
	protected int id_lancamento;
	protected Date data;
	
	
	
	public int getId_lancamento() {
		return id_lancamento;
	}
	public void setId_lancamento(int id_lancamento) {
		this.id_lancamento = id_lancamento;
	}
	
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
}
