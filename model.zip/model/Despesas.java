package model;

import java.sql.Date;

public class Despesas extend Lancamento {
	protected int id_despesa;
	protected float valor;

	public int getId_despesa() {
		return id_despesa;
	}
	public void setId_despesa(int id_despesa) {
		this.id_despesa = id_despesa;
	}
	
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	
	
}
