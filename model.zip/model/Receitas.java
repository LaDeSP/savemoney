package model;

import java.util.Scanner;


public class Receitas extend Lancamento {
	protected int receita;
	protected float valor;
	protected double RECEITAS = '0';

	public int getReceita() {
		return receita;
	}
	public void setReceita(int id_receita) {
		this.receita = receita;
	}
	
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}

	public void Lancamento(Date data, float valor, String descricao){
		this.data = data;
		this.valor = valor;
		this.descricao = descricao;
	}
	
	
}
